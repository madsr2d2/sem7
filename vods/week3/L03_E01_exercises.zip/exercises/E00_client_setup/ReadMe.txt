See section 2.1 in the exercise PDF.
