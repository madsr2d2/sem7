
def adder_model(a: int, b: int) -> int:
    """model of adder"""
    return a + b
