See section 2.2 in the exercise PDF.
